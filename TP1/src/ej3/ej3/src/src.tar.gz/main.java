import java.util.TreeMap;
import java.util.TreeSet;

void procesar_fogon(TreeSet)

int main(){
	
}