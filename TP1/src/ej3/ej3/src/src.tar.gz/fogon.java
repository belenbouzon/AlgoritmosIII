import java.util.TreeMap;
import java.util.TreeSet;

public class fogon {
	
	private char exploradoras[];
	private char exploradoras_en_array[];
	private Tuple<char,char> exploradoras_con_amigas[];
	int cantidad_;
	private int indice_iteracion_1;
	private int indice_iteracion_2;
	public fogon (TreeSet<char> exploradoras_totales, int cantidad,TreeMap<char,TreeSet<char> > amigas){
		this.cantidad_ = cantidad;
		int i = 0;
		int j = 0;
		//for(i=0;i<cantidad;i++){
		TreeSet.Iterator<char> it = exploradoras_totales.iterator();
		while(it.hasNext( )){
			this.exploradoras[i] = i;
			if(amigas.constainKey(i)){
				exploradoras_con_amigas[j].y = i;
				exploradoras_con_amigas[j].x = i;
				exploradoras_en_array[i] = j;
				j++;
			}else{
				exploradoras_en_array[i] = -1;
			}
		}
	};
	public const char* alternar_fogon(){
		if(this.indice_iteracion_2==this.cantidad_){
			return 0;
		}
		if(this.indice_iteracion_1 == this.cantidad_){
			this.indice_iteracion_2++;
			this.indice_iteracion_1 = 0;
		} 
		if(exploradoras_en_array[this.indice_iteracion_1]!= -1 && exploradoras_en_array[this.indice_iteracion_1+1]!= -1){
			if(exploradoras_en_array[this.indice_iteracion_1]!=-1){
				exploradoras_con_amigas[exploradoras_en_array[this.indice_iteracion_1]].y = this.indice_iteracion_1+1;
			}
			if(exploradoras_en_array[this.indice_iteracion_1+1]!=-1){
				exploradoras_con_amigas[exploradoras_en_array[this.indice_iteracion_1+1]].y = this.indice_iteracion_1;
			}
			int swap = this.exploradoras [this.indice_iteracion_1];
			this.exploradoras [this.indice_iteracion_1] = this.exploradoras [this.indice_iteracion_1+1];
			this.exploradoras [this.indice_iteracion_1+1] = swap;
			
			swap = this.exploradoras_en_array [this.indice_iteracion_1];
			this.exploradoras_en_array [this.indice_iteracion_1] = this.exploradoras_en_array [this.indice_iteracion_1+1];
			this.exploradoras_en_array [this.indice_iteracion_1+1] = swap;
		}
		return this.exploradoras;
	}
	public boolean hay_mas_fogones(){
		return (this.indice_iteracion_2!=n)
	}
	public const Tuple<char,char>* dame_exploradoras_con_amigas(){
		return (this.exploradoras_con_amigas);
	}
	
};
